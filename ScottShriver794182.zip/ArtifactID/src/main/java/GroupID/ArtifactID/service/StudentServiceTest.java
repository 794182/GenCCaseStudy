package GroupID.ArtifactID.service;

public class StudentServiceTest {
}
